package com.miaxis.weomosdk.message.callback;

/**
 * @ClassName: CallbackFactory
 * @Author: cheng.peng
 * @Date: 2022/5/26 18:20
 * 设备向协议层发送回调的工厂
 *
 * 基本格式
 *
 */
public class CallbackFactory {
}
