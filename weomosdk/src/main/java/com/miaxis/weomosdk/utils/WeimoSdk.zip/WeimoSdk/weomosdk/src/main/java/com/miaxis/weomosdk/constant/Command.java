package com.miaxis.weomosdk.constant;

/**
 * @ClassName: Command
 * @Author: cheng.peng
 * @Date: 2022/5/26 14:07
 */
public class Command {
    public static final String AUTH="AUTH";
    public static final String PUSH_DATA="PUSH_DATA";
    public static final String PUSH_DATA_BACK="PUSH_DATA_BACK";
    public static final String PING="PING";
    public static final String PONG="PONG";
    public static final String UPLOAD_DATA="UPLOAD_DATA";

    public static final String AUTH_BACK="AUTH_BACK";
}
