package com.miaxis.weomosdk.entity;

/**
 * @ClassName: ResponseLoginBean
 * @Author: cheng.peng
 * @Date: 2022/8/12 15:42
 */
public class ResponseLoginBean {

    private Integer userId;

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }
}
