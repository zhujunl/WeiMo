package com.miaxis.weomosdk.api;

/**
 * @ClassName: ZZCallback
 * @Author: cheng.peng
 * @Date: 2022/6/16 16:36
 */
public interface ZZCallback {
    boolean response(ZZResponse response);
}
