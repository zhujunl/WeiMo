package com.miaxis.weomosdk.entity;

/**
 * @ClassName: ResponseAuthBean
 * @Author: cheng.peng
 * @Date: 2022/9/14 17:05
 */
public class ResponseAuthBean {

    private String authresp;

    public String getAuthresp() {
        return authresp;
    }

    public void setAuthresp(String authresp) {
        this.authresp = authresp;
    }
}
