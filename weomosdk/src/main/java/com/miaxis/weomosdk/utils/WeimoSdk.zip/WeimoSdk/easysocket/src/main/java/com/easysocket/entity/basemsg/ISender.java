package com.easysocket.entity.basemsg;

import java.io.Serializable;

/**
 * Author：Alex
 * Date：2019/6/1
 * Note：发送数据的接口
 */
public interface ISender extends Serializable {
}
