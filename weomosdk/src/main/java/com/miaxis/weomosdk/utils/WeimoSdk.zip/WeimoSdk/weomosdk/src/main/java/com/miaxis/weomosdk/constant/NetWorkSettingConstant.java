package com.miaxis.weomosdk.constant;

/**
 * 网络设置的常量类保存
 */
public class NetWorkSettingConstant {
    public static final String NATIVE_IP="";//本机ip
    public static final String NATIVE_PORT="";//本机端口
    public static  String SERVER_IP="192.168.11.183";//服务端ip
    public static  String SERVER_PORT="19999";//服务端端口
    public static final String REGISTER_ID="";//注册id(就是client_id)


}
