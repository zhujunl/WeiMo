package com.easysocket.connection.action;

/**
 * Author：Alex
 * Date：2019/6/3
 * Note：
 */
public interface IOAction {
    // 收到消息响应
    String ACTION_READ_COMPLETE = "action_read_complete";
}
