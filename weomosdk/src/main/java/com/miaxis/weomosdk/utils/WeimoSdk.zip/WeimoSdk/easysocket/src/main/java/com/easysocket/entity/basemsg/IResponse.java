package com.easysocket.entity.basemsg;

/**
 * Author：Alex
 * Date：2019/12/8
 * Note：
 */
public interface IResponse {
}
