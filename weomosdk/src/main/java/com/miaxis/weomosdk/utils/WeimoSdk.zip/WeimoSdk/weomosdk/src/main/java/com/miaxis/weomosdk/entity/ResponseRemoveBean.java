package com.miaxis.weomosdk.entity;

/**
 * @ClassName: ResponseRemoveBean
 * @Author: cheng.peng
 * @Date: 2022/9/14 16:24
 */
public class ResponseRemoveBean {

    private String deactiveinfo;

    public String getDeactiveinfo() {
        return deactiveinfo;
    }

    public void setDeactiveinfo(String deactiveinfo) {
        this.deactiveinfo = deactiveinfo;
    }
}
