package com.miaxis.weomosdk.constant;

/**
 * @ClassName: Constant
 * @Author: cheng.peng
 * @Date: 2022/5/26 14:00
 */
public class Constant {
    public static  String APP_KEY="";
    public static  String APP_SECRET="";
    public static String CLIENT_ID="9906240014";
    public static String DEVICE_CHANNEL="";
    public static String DEVICE_NUMBER="";
    public static String CHANNEL_NAME="";



    public static String CID="226062ee9fba4316ac0357f86de259a3";
    public static String SAMID="0523201909270000000182";
    public static String DEVICE_ID="0523201909270000000182";

    public static boolean IS_INIT=false;


}
