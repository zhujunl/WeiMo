package com.easysocket.exception;

/**
 * Author：Alex
 * Date：2019/6/5
 * Note：初始化异常
 */
public class InitialExeption extends RuntimeException{
    public InitialExeption(String s){
        super(s);
    }
}
