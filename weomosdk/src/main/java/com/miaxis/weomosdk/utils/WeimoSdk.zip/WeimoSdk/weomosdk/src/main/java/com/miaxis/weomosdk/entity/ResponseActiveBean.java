package com.miaxis.weomosdk.entity;

/**
 * @ClassName: ResponseActiveBean
 * @Author: cheng.peng
 * @Date: 2022/9/14 16:22
 */
public class ResponseActiveBean {

    private String activeinfo;
    private String mdeviceid;

    public String getActiveinfo() {
        return activeinfo;
    }

    public void setActiveinfo(String activeinfo) {
        this.activeinfo = activeinfo;
    }

    public String getMdeviceid() {
        return mdeviceid;
    }

    public void setMdeviceid(String mdeviceid) {
        this.mdeviceid = mdeviceid;
    }
}
