package com.miaxis.weimosdk;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.miaxis.weomosdk.WeiMoFacade;
import com.miaxis.weomosdk.api.ZZCallback;
import com.miaxis.weomosdk.api.ZZResponse;
import com.miaxis.weomosdk.constant.Constant;
import com.miaxis.weomosdk.utils.HandlerHelper;
import com.miaxis.weomosdk.utils.LocationUtils;
import com.miaxis.weomosdk.utils.MacUtils;
import com.miaxis.weomosdk.utils.MmkvHelper;

import javax.crypto.Mac;

public class MainActivity extends AppCompatActivity {
    private String TAG=MainActivity.class.getSimpleName();
    private TextView loginBtn;
    private TextView activeBtn;
    private TextView removeBtn;
    private TextView authBtn;
    private TextView getInfoBtn;
    private TextView resultEt;

    private EditText ipEt;
    private EditText portEt;

    private EditText userRegisterEt;
    private EditText cidEt;
    private EditText smidEt;
    private EditText authEt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
        initListener();
    }



    private void  initView(){
        loginBtn=findViewById(R.id.wei_mo_login);
        activeBtn=findViewById(R.id.active_wei_mo);
        removeBtn=findViewById(R.id.remove_wei_mo);
        authBtn=findViewById(R.id.auth_wei_mo);
        getInfoBtn=findViewById(R.id.get_wei_mo);
        resultEt=findViewById(R.id.result_tv);

        userRegisterEt=findViewById(R.id.user_name_et);
        cidEt=findViewById(R.id.cid_et);
        smidEt=findViewById(R.id.smid_et);
        authEt=findViewById(R.id.auth_et);
        ipEt=findViewById(R.id.ip_et);
        portEt=findViewById(R.id.port_et);
    }

    private void  initListener(){


        loginBtn.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View v) {
                WeiMoFacade.init(MainActivity.this,ipEt.getText().toString(),portEt.getText().toString(), userRegisterEt.getText().toString(), new ZZCallback() {
                    @Override
                    public boolean response(ZZResponse response) {
                        if(response.code==0){
                            showText("设备初始化成功");
                            activeBtn.setEnabled(true);
                        }else {
                            activeBtn.setEnabled(false);
                            authBtn.setEnabled(false);
                            removeBtn.setEnabled(false);
                        }
                        return false;
                    }
                });
            }
        });

        activeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                WeiMoFacade.activeWeiMo(cidEt.getText().toString(), smidEt.getText().toString(), new ZZCallback() {
                    @Override
                    public boolean response(ZZResponse response) {
                        if(response.code==0){
                            showText("激活成功");
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                   activeBtn.setEnabled(false);
                                    authBtn.setEnabled(true);
                                    removeBtn.setEnabled(true);
                                }
                            });
                        }else if(response.code==-2) {
                            showText("请先将初始化");
                        }else {
                            showText("激活失败");
                        }
                        return false;
                    }
                });
            }
        });
        removeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                WeiMoFacade.removeWeiMo(new ZZCallback() {
                    @Override
                    public boolean response(ZZResponse response) {
                        if(response.code==0){
                            showText("解除激活成功");
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    activeBtn.setEnabled(true);
                                    authBtn.setEnabled(false);
                                    getInfoBtn.setEnabled(false);
                                    removeBtn.setEnabled(false);
                                }
                            });
                        }

                        return false;
                    }
                });
            }
        });

        authBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               WeiMoFacade.authorizeWeiMo(authEt.getText().toString(), new ZZCallback() {
                   @Override
                   public boolean response(ZZResponse response) {
                      if(response.code==0){
                          showText("授权成功");
                          getInfoBtn.setEnabled(true);
                      }else {
                          getInfoBtn.setEnabled(false);
                      }

                       return false;
                   }
               });
            }
        });

        getInfoBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              WeiMoFacade.readPersonInfo("MDUyMzIwMTkwOTI3MDAwMDAwMDE3MDIwMjAyMDIwMjAyMDIwMjAyADAAMAA3ADAANAAzADAAf5UfZyAAIAAgACAAIAAgAIjwbCLl1Hhz91I4O2aAmNYBrgx5m9O6v/cjDlB0uP52RmJLAOqaMv4E1rdmAFkUyPatXAj+ehHIJwxWXGgDRYwQIySMR4xh/Al2Nt0hEUAjM2Ai4oLtFEZ2HdT+0npYU5xbUlyGLGMFp8mofeZkqD9oFCVnzVuJnFdBc0FXfAhATgO+Y0q0wz+lOzT/5pBi/ynM5GTznxEPxxDekbp3r8KoXbqEStQWTuBpMY6YkSQ+9h8WkPPhvy12X8hN7yj3JipKLYUNhma1tMJgRdu28XCxDSmMlbtrXnwmTXWfmYsSIiljfKGS3GZC7Dw2Rbdr3k+8Np5gafzrDvmecCHNUrg2LOEvQVuMojaK80vqXSnGaGeMdUYLp+Y21MlgolriCwXXB+Erahta2atUbZdvX17BNwbiG4Fl/j89+++5+iAY+XG3cus6X7xr6QThquvnentG56BulpJVRatU0+3AGyxNWXVB4qu3t0iaC5tVaVe7JXZqDUVND73PDlON0ttEHVVSd1jahLbj5/libyhoEy2PxQLsammdjgWXQ8XVykVV6Hp+9FbaxKAomc4w2Ie6h8eDfsZIPCkL0w1PnvgA05VXc3R0lxndiX2H2gNXvZ9yFAtJXY6mrBtaYkLPbXd2uHRzOx1b8hlTsiDEdO9cXpWAE7NbWSTTN/U/NNOuDUi6vph+DnVJXMFdmYXLcaAI4kpYCtAHoGhPeBaDVbmpZDU=",
                      "MIIBoTCCAUagAwIBAgITMDA1MjMxOTA5MjcwMDAwMDE3MDAMBggqgRzPVQGDdQUAMD4xCzAJBgNVBAYTAkNOMQ8wDQYDVQQKEwZHQUhaWlgxDDAKBgNVBAsTA0tEQzEQMA4GA1UEAxMHU0FNUk9PVDAeFw0yMjA3MDgwMzAzMzZaFw0zMjA3MDUwMzAzMzZaME0xCzAJBgNVBAYTAkNOMQ8wDQYDVQQKEwZHQUhaWlgxDDAKBgNVBAsTA0tEQzEfMB0GA1UEAxMWMDUyMzIwMTkwOTI3MDAwMDAwMDE3MDBZMBMGByqGSM49AgEGCCqBHM9VAYItA0IABDi9QSvs1V3ssMQeZjScortGclUpu9XtsNv0ivpxIkFRiHcTORhsBSqzCi8XAjPfg9apjfs/VCsSqcCWPjlwieujEjAQMA4GA1UdDwEB/wQEAwIGwDAMBggqgRzPVQGDdQUAA0cAMEQCIE9KL0H90yb6pvT3nHvAGN3o5ItO9kDKCa9J+nQ2D/EVAiBBiMi466VvdoNDZu/7QP0MvqONdA5/AYJ/VaKH1K3LxA==", new ZZCallback() {
                  @Override
                  public boolean response(ZZResponse response) {
                      if(response.code==0){
                          showText("获取身份信息成功");
                      }

                      return false;
                  }
              });
            }
        });
    }




    void showText(String text) {
        HandlerHelper.post(new Runnable() {
            @Override
            public void run() {
                //   resultTv.setText("");
                resultEt.setText(text);
                // resultTv.append("\n");
            }
        });

    }



}