package com.easysocket.exception;

/**
 * Author：Alex
 * Date：2019/6/4
 * Note：请求取消异常
 */
public class RequestCancelException extends Exception{

    public RequestCancelException(String s){
        super(s);
    }
}
