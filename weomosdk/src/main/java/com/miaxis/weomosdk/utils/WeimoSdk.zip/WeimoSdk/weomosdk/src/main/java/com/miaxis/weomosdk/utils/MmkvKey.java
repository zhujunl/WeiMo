package com.miaxis.weomosdk.utils;

public enum MmkvKey {
    LOGTYPE,
    AccessToken,
    UserId,
    IsLogin,
}
